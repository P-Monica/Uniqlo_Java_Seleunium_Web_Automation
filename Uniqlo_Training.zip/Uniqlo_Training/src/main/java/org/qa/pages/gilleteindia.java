package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class gilleteindia 
{
	
	WebDriver driver;
	
	@FindBy(xpath="//a[@title='REGISTER']")
	WebElement register;
	
	@FindBy(xpath="//input[@data-key='firstName']")
	WebElement firstname;
	
	@FindBy(xpath="//input[@data-key='lastName']")
	WebElement lastname;
	
	@FindBy(xpath="//input[@data-key='emailAddress']")
	WebElement email;
	
	@FindBy(xpath="//input[@data-key='newPassword']")
	WebElement password;
	
	@FindBy(xpath="//input[@validationregexerror='Password and Confirm Password values must match. Please try again.']")
	WebElement confirmpass;
	
	@FindBy(xpath="//select[@id='phdesktopbody_0_grs_consumer[birthdate][month]']")
	WebElement month;
	
	@FindBy(xpath="//select[@id='phdesktopbody_0_grs_consumer[birthdate][year]']")
	WebElement year;
	
	@FindBy(xpath="//input[@data-key='addressPostalCode']")
	WebElement postalcode;
	
	@FindBy(xpath="//input[@type='checkbox']")
	WebElement check;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement submit;
	
	@FindBy(xpath="//input[@data-key='signInEmailAddress']")
	WebElement signinemail;
	
	@FindBy(xpath="//input[@data-key='currentPassword']")
	public WebElement signinpassword;
	
	
	public gilleteindia(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void clickreg()
	{
		register.click();
		
	}
	public void enterfirstname(String username)
	{
		firstname.sendKeys(username);
	}
	
	public void enterlastname(String lname)
	{
		lastname.sendKeys(lname);
	}
	public void enteremail(String em)
	{
		email.sendKeys(em);
	}
	public void enterpass(String pa)
	{
		password.sendKeys(pa);
	}
	public void entercpass(String cpa)
	{
		confirmpass.sendKeys(cpa);
	}
	
	public void entermonth(String mo)
	{
		Select s=new Select(month);
		s.selectByValue(mo);
	}
	public void enteryear(String yr)
	{
		Select s1=new Select(year);
		s1.selectByValue(yr);
	}
	public void enterpasscode(String pc)
	{
		postalcode.sendKeys(pc);
	}
	public void clickcheck()
	{
		check.click();
	}
	public void clicksub()
	{
		submit.click();
	}
	
	public void entersigninemail(String eem)
	{
		signinemail.sendKeys(eem);
	}
	
	public void entersignpass(String passs)
	{
		signinpassword.sendKeys(passs);
	}
	
	
	
	
}
