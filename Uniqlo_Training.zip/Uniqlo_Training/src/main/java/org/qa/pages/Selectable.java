package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class Selectable 
{
	WebDriver driver;
	
	@FindBy(xpath="//a[@href='#Default']")
	WebElement Defaultfuncuntion;
	
	@FindBy(xpath="//a[@href='#Serialize']")
	WebElement Serialize;
	
	@FindBy(xpath="//*[@id='Serialize']/ul/li[1]")
	WebElement selectone;
	 
	
	
	public Selectable(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void click_default()
	{
		Defaultfuncuntion.click();
	}
	
	public void click_serialize()
	{
		Serialize.click();
	}
	
	public void selectone_click()
	{
		selectone.click();
	}
	
	
      

}
