package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class frame 
{
WebDriver driver;

@FindBy(xpath="//iframe[@id='singleframe']")
WebElement singleframe;

@FindBy(xpath="//input[@type='text']")
WebElement entertext;

@FindBy(xpath="//a[@href='#Multiple']")
WebElement iframemultipleink;

@FindBy(xpath="//iframe[@src='MultipleFrames.html']")
WebElement firstframe;

@FindBy(xpath="//iframe[@src='SingleFrame.html']")
WebElement frameinside;


public frame(WebDriver driver)
{
	this.driver=driver;
	PageFactory.initElements(driver, this);
}
public void switchToFrame()
{
	driver.switchTo().frame(singleframe);
}
public void switchToFrame1()
{
	driver.switchTo().frame(firstframe);
}
public void entertext()
{
	entertext.sendKeys("Monica");
}

public void multipleink()
{
	iframemultipleink.click();
}

public void switchToFrameInside()
{
	driver.switchTo().frame(frameinside);
}


}