package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Registration {
	WebDriver driver;
	
	@FindBy(xpath="//input[@ng-model='FirstName']")
	WebElement firstname;
	
	@FindBy(xpath="//input[@ng-model='LastName']")
	WebElement lastname;
	
	@FindBy(xpath="//textarea[@ng-model='Adress']")
	WebElement Address;
	
	@FindBy(xpath="//input[@ng-model='EmailAdress']")
	WebElement Emailid;
	
	@FindBy(xpath="//input[@ng-model='Phone']")
	WebElement Phoneno;
	
	@FindBy(xpath="//input[@value='FeMale']")
	WebElement Female;
	
	@FindBy(xpath="//input[@value='Cricket']")
	WebElement Hobbies;
	
	@FindBy(id="msdd")
	WebElement language;
	
	@FindBy(xpath="//*[@id='Skills']")
	WebElement Skills;
	
	
	@FindBy(xpath="//*[@id='countries']")
	WebElement country;
	
	@FindBy(xpath="//select[@id='yearbox']")
	WebElement year;
	
	@FindBy(xpath="//select[@ng-model='monthbox']")
	WebElement month;
	
	@FindBy(xpath="//select[@id='daybox']")
	WebElement day;
	
	@FindBy(id="firstpassword")
	WebElement firstpassword;
	
	@FindBy(id="secondpassword")
	WebElement secondpassword;
	
		
	@FindBy(id="submitbtn")
	WebElement submit;
	
	
	public Registration(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void enterFirstName(String firstn)
	{
		firstname.sendKeys(firstn);
		
	}
	public void enterLasttName(String lastn)
	{
		lastname.sendKeys(lastn);
		
	}
	
	public void enterAddress(String add)
	{
		Address.sendKeys(add);
		
	}
	
	public void enteremail(String ema)
	{
		Emailid.sendKeys(ema);
		
	}
	
	public void enterPhone(String phh)
	{
		Phoneno.sendKeys(phh);
		
	}
	
	public void entergender()
	{
		Female.click();
		
	}
	public void enterhobby()
	{
		Hobbies.click();
	}
	
	public void selectSkills(String drop)
	{
		Select s= new Select(Skills);
		s.selectByValue(drop);
	}
	public void selectcountry(String coun)
	{
		Select s= new Select(country);
		s.selectByValue(coun);
	}
	public void selectYear(String yr)
	{
		Select s= new Select(year);
		s.selectByValue(yr);
	}
	
	public void selectmonth()
	{
		Select s= new Select( month);
		s.selectByIndex(2);
	}
	
	public void selectday()
	{
		Select s= new Select(day);
		s.selectByIndex(2);
	}
	
	public void enterpassword(String pass)
	{
		firstpassword.sendKeys(pass);
	}
	
	public void entersecondpassword(String spass)
	{
		secondpassword.sendKeys(spass);
	}
	
		
	public void clicksubmit()
	{
		submit.click();
	}
	
	
}




