package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class datepicker {
WebDriver driver;

	@FindBy(xpath="//input[@class='form-control is-datepick']")
	WebElement datepickers;
	
	@FindBy(xpath="//a[contains(text(),'16')]")
	WebElement date;
	
	public datepicker(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void datepicker_click()
	{
		datepickers.click();
	}
	
	public void date_click()
	{
		date.click();
	}
}
