package org.qa.pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class gilleteaustria 
{
	
	WebDriver driver;
	
	@FindBy(xpath="//input[@id='customerName']")
	WebElement name;
	
	@FindBy(xpath="//input[@id='customerEmail']")
	WebElement email;
	
	@FindBy(xpath="//input[@id='confirmCustomerEmail']")
	WebElement confirmemail;
	
	@FindBy(xpath="//input[@id='customerPassword']")
	WebElement customerpass;
	
	@FindBy(xpath="//input[@id='confirmPassword']")
	WebElement confirmcuspass;
	
	@FindBy(xpath="//input[@id='referrerCode']")
	WebElement refercode;
	
	@FindBy(xpath="//input[@id='OptInReceiveNewsLetterRadio1']")
	WebElement radio1;
	
	@FindBy(xpath="//button[@class='accountSignUp_submitButton']")
	WebElement submitbutton;
	
	public gilleteaustria(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void enterfirstname(String username)
	{
		name.sendKeys(username);
	}
	
	public void enteremail(String em)
	{
		email.sendKeys(em);
	}
	public void enterconfirmemail(String pa)
	{
		confirmemail.sendKeys(pa);
	}
	public void entercpass(String cpa)
	{
		customerpass.sendKeys(cpa);
	}
	
	public void enterconfpass(String cp)
	{
		confirmcuspass.sendKeys(cp);
	}
	
	public void enterrefcode(String rc)
	{
		refercode.sendKeys(rc);
	}
	
	public void reg()
	{
		radio1.click();
	}
	
	public void registerbutton()
	{
		submitbutton.click();
	}
	
}

	
	
	
