package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class windows 
{
	WebDriver driver;
	
	@FindBy(xpath="//a[contains(text(),'Open New Tabbed Windows')]")
	WebElement opennewtab;
	
	@FindBy(xpath="//button[@class='btn btn-info']")
	WebElement clickfirsttab;
	
	@FindBy(xpath="//a[contains(text(),'Open New Seperate Windows')]")
	WebElement newsepartewindow;
	
	@FindBy(xpath="//button[@class='btn btn-primary']")
	WebElement clickstab;
	
	@FindBy(xpath="//a[@href='#Multiple']")
	WebElement multipletab;
	
	@FindBy(xpath="//*[@id='Multiple']/button")
	WebElement multipleclick;
	
	public windows(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public void opennew()
	{
		opennewtab.click();
	}
	public void firsttab()
	{
		clickfirsttab.click();
	}
	
	public void opensecondtab()
	{
		 newsepartewindow.click();
	}
	
	public void clicksecondtab()
	{
		clickstab.click();
	}
	
	public void clickmultipletab()
	{
		multipletab.click();
	}
	public void clickthirdtab()
	{
		multipleclick.click();
	}
	
	
	
	
}
