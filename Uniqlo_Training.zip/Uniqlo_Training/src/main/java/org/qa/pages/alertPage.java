package org.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class alertPage 
{

	WebDriver driver;
	
	@FindBy(xpath="//a[@href='#OKTab']")
	WebElement firstalertlink;
	
	@FindBy(xpath="//*[@id='OKTab']/button")
	WebElement firstalert;
	
	@FindBy(xpath="//a[contains(text(),'Alert with OK & Cancel ')]")
	WebElement secondalertlink;
	
	@FindBy(xpath="//button[contains(text(),'click the button to display a confirm box ')]")
	WebElement secondalert;
	
	@FindBy(xpath="//a[@href='#Textbox']")
	WebElement thirdalertlink;
	
	@FindBy(xpath="//button[contains(text(),'click the button to demonstrate the prompt box ')]")
	WebElement thirdalert;
	
	@FindBy(xpath="//*[@id='demo']")
	WebElement pressok;
	
	@FindBy(xpath="//*[@id='demo1']")
	WebElement text;
	
	
	public alertPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
	}

	
	public void firstalertl()
	{
		firstalertlink.click();
	}
	
	
	public void firstalerts()
	{
		firstalert.click();
	}
	public void secondalertlinks()
	{
		secondalertlink.click();
	}
	public void secondalerts()
	{
		secondalert.click();
	}
	public void thirdalertlinks()
	{
		thirdalertlink.click();
	}
	
	public void thirdalerts()
	{
		thirdalert.click();
	}
	
	public String gettingtext()
	{
		String str=pressok.getText();
		return str;
	}
	
	public String gettingtextal()
	{
		String str1=text.getText();
		return str1;
	}

	

	
}
