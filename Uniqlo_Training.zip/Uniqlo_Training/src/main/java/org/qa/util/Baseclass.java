package org.qa.util;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Baseclass {
	public void launchBrowser()throws IOException
	{
		FileReader reader=new FileReader("Configuration.properties");  
		
		//creating properties class to get data from the properties file 
		Properties pro=new Properties();  
		
		//It loads data from the FileReader object
	    pro.load(reader);  
	      
	    //getproperty will returns value based on the key 
	    String brows=pro.getProperty("browser");
	    if(brows.equals("chrome"))
	    {
	    	System.setProperty("webdriver.chrome.driver","E:\\Java_Workspace\\Automation Project\\Uniqlo_Training\\chromedriver.exe");
	    }
	    
	}   
	
	 
	 public String registerationlink() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("Registerurl"));  
		    
		    String launchurl=p.getProperty("Registerurl");
		    
		    return launchurl;
		    
		    
		}
	 
	 public String alertlink() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("alerturl"));  
		    
		    String launchurl=p.getProperty("alerturl");
		    
		    return launchurl;
		 		    
		}
	 
	 public String windowlink() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("windowurl"));  
		    
		    String launchurl=p.getProperty("windowurl");
		    
		    return launchurl;
		 		    
		}
	 
	 public String frameslink() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("framesurl"));  
		    
		    String launchurl=p.getProperty("framesurl");
		    
		    return launchurl;
		 		    
		}
	 
	 public String selectablelink() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("selectableurl"));  
		    
		    String launchurl=p.getProperty("selectableurl");
		    
		    return launchurl;
		 		    
		}
	 
	 public String datepickerlink() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("datepickerurl"));  
		    
		    String launchurl=p.getProperty("datepickerurl");
		    
		    return launchurl;
		 		    
		}
	
	    public String lauchIndia() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("urlIndia"));  
		    
		    String launchurl=p.getProperty("urlIndia");
		    
		    return launchurl;
		    
		    
		}
		
		public String lauchAustria() throws IOException
		{
			FileReader reader=new FileReader("Configuration.properties");  
			Properties p=new Properties();  
			
		    p.load(reader);  
		      
		    System.out.println(p.getProperty("urlaustria"));  
		    
		    String launchurl=p.getProperty("urlaustria");
		    
		    return launchurl;
		    
		    
		}
		



  
	}
	
	

