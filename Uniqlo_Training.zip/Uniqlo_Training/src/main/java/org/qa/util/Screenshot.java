package org.qa.util;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot
{
	 
	
	public static String takeSnapshot(WebDriver driver) throws IOException
	{
		
		
		//Convert web driver object to TakeScreenshot

		TakesScreenshot scrShot =((TakesScreenshot)driver);

		//Call getScreenshotAs method to create image file

		        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

		    //Move image file to new destination
		        
		        Random r=new Random();
		        int a=r.nextInt();
		        
		        String i="img"+a;
		        
		        String image="E:\\Java_Workspace\\Report\\Screenshots\\"+i+".jpg";

		        File DestFile=new File(image);

		        //Copy file at destination

		        FileUtils.copyFile(SrcFile, DestFile);
		        
		        return image;
	}

}
