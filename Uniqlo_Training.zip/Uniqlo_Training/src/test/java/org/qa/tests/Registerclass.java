package org.qa.tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.qa.pages.Registration;
import org.qa.util.Baseclass;
import org.qa.util.Screenshot;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Registerclass extends Baseclass
{
	ExtentReports report;
	//Extent Test class is used to log test steps onto the generated HTML report
	ExtentTest logger; 
	WebDriver driver;
	String exptitle="Register";
	Registration p;
	Baseclass b=new Baseclass();
	
	@Test
	public void registrationPage()throws IOException, FilloException 
	{
		b.launchBrowser();
		driver=new ChromeDriver();
		p=new Registration(driver);
		//Extent Reports class is used to generate an HTML report on the user-specified path
		report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo.html");
		//log method is used to log the status of each test step onto the resultant HTML report
		//Syntax:test.log(LogStatus.PASS,”Test Passed”);
		 logger=report.startTest("registrationPage");
		driver.manage().window().maximize();
		 logger.log(LogStatus.INFO, "Browser started ");
		 String baseUrl=b.registerationlink();
		 driver.get(baseUrl);
		 logger.log(LogStatus.INFO, "Application is up and running");
		 String title=driver.getTitle();
		 System.out.println(title);
		 Assert.assertTrue(title.contains("Register")); 
		  logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+exptitle+"Actual Title:"+" "+title);
		  
		  String firstname="";
			String lastname="";
			String  address="";
			String emailid="";
			String Phoneno="";
			String skill="";
			String country="";
			String year="";
			String month="";
			String day="";
			String password="";
			String confirmpassword="";
		
		String excelPath="E:\\Java_Workspace\\Automation Project\\Uniqlo_Training\\Form.xlsx";
		System.out.println(excelPath);
		//Create an Object of Fillo Class
	    
		Fillo fillo = new Fillo();
	    //Create an Object for Connection class and use getConnection()
	    Connection connection = fillo.getConnection(excelPath);
	    //Select all the values present in a sheet
	    String strSelectQuerry = "Select * from Sheet1";
	    System.out.println(strSelectQuerry);
	    
	  //Execute the Select query 
	    	Recordset recordset =null;
	        recordset = connection.executeQuery(strSelectQuerry);
	   //use while loop to iterate through all columns and rows 
	    while(recordset.next())
	    {
	    	firstname = recordset.getField("FirstName");
	      System.out.println("Firstname  is:"+firstname);
	      lastname=recordset.getField("LastName");
	      System.out.println("LastName is:"+lastname);
	      address=recordset.getField("Address");
	      System.out.println("Address is:"+address);
	      emailid=recordset.getField("Email");
	      System.out.println("Email is:"+emailid);
	      Phoneno=recordset.getField("Phone");
	      System.out.println("Phone is:"+Phoneno);
	      skill=recordset.getField("Skills");
	      System.out.println("Skills is:"+skill);
	      country=recordset.getField("Country");
	      System.out.println("Country is:"+country);
	      year=recordset.getField("Year");
	      System.out.println("Year is:"+year);
	      month=recordset.getField("Month");
	      System.out.println("Month is:"+month);
	      day=recordset.getField("Day");
	      System.out.println("Day is:"+ day);
	      password=recordset.getField("Password");
	      System.out.println("Password is:"+ password);
	      confirmpassword=recordset.getField("Confpass");
	      System.out.println("Confpass is:"+confirmpassword);
	    }
			  
		  driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		  p.enterFirstName(firstname);
		  p.enterLasttName(lastname);
		  p.enterAddress(address);
		  p.enteremail(emailid);
		  p.enterPhone(Phoneno);
		  p.entergender();
		  p.enterhobby();
		  p.selectSkills(skill);
		  p.selectcountry(country);
		  p.selectYear(year);
		  p.selectmonth();
		  p.selectday();
		  p.enterpassword(password);
		  p.entersecondpassword(confirmpassword);
		  p.clicksubmit();
		  
		  String img=Screenshot.takeSnapshot(driver);
		  logger.log(LogStatus.PASS,logger.addScreenCapture(img)+ "Test Passed");
	}
		  
		  @AfterMethod
		  public void tearDown(ITestResult result)
		  {

		  report.endTest(logger);
		  report.flush();
		   

		  }
		  
		
	}

			

	 

		 
		  
		

