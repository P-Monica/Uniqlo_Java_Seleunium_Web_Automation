package org.qa.tests;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.qa.pages.gilleteindia;
import org.qa.util.Baseclass;
import org.qa.util.Screenshot;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class gilleteindclass extends Baseclass
{
	ExtentReports report;
	ExtentTest logger; 
	WebDriver driver;
	
	String exptitle="Men's razors and shavers | Gillette India";
			
	String exptitle1="Create Profile";
	String succ="Your Registration Is Complete";
	gilleteindia p7;
	Baseclass b=new Baseclass();
	@Test
	public void gilleteindiaPage()throws IOException, InterruptedException, FilloException 
	{
		b.launchBrowser();
		driver=new ChromeDriver();
		 String baseUrl=b.lauchIndia();
		 driver.get(baseUrl);
		p7=new gilleteindia(driver);
		report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo7.html");
		 logger=report.startTest("gilleteindiaPage");
		driver.manage().window().maximize();
		 logger.log(LogStatus.INFO, "Browser started ");
		 String title=driver.getTitle();
		 System.out.println(title);
		 Assert.assertTrue(title.contains(exptitle)); 
		  logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+exptitle+"Actual Title:"+" "+title);
		  String fname="";
			String lname="";
			String email="";
			String yr="";
			String mon="";
			String pass="";
			String confpass="";
			String postal="";
		
		String excelPath="E:\\Java_Workspace\\Automation Project\\Uniqlo_Training\\Form1.xlsx";
		System.out.println(excelPath);
		//Create an Object of Fillo Class
	    
		Fillo fillo = new Fillo();
	    //Create an Object for Connection class and use getConnection()
	    Connection connection = fillo.getConnection(excelPath);
	    //Select all the values present in a sheet
	    String strSelectQuerry = "Select * from Sheet1";
	    System.out.println(strSelectQuerry);
	    
	  //Execute the Select query 
	    	Recordset recordset =null;
	        recordset = connection.executeQuery(strSelectQuerry);
	   //use while loop to iterate through all columns and rows 
	    while(recordset.next())
	    {
	       fname = recordset.getField("FirstName");
	      System.out.println("Firstname  is:"+fname);
	       lname=recordset.getField("LastName");
	      System.out.println("LastNmae is:"+lname);
	      email=recordset.getField("Email");
	      System.out.println("Email is:"+email);
	     pass=recordset.getField("Password");
	      System.out.println("Password is:"+ pass);
	      confpass=recordset.getField("Confpass");
	      System.out.println("Confpass is:"+confpass);
	      mon=recordset.getField("Month");
	      System.out.println("Month is:"+mon);
	      yr=recordset.getField("Year");
	      System.out.println("Year is:"+yr);
	      postal=recordset.getField("Postalcode");
	      System.out.println("Postalcode is:"+postal);	  
	    }
	    
	    p7.clickreg();
	    p7.enterfirstname(fname);
	    p7.enterlastname(lname);
	    p7.enteremail(email);
	    p7.enterpass(pass);
	    p7.entercpass(confpass);
	    p7.entermonth(mon);
	    p7.enteryear(yr);
	    p7.enterpasscode(postal);
	    p7.clickcheck();
	    String img1=Screenshot.takeSnapshot(driver);
		  logger.log(LogStatus.PASS,logger.addScreenCapture(img1)+ "Registration is successful");
		  
	    p7.clicksub();
	    
	    String title1=driver.getTitle();
	    
	    Assert.assertTrue(title1.contains("Your Registration Is Complete")); 
	    logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+succ+"Actual Title:"+" "+title1);
	    String img=Screenshot.takeSnapshot(driver);
		  logger.log(LogStatus.PASS,logger.addScreenCapture(img)+ "Sign in");
		  p7.entersigninemail(email);
		  p7.entersignpass(confpass);
		
		  
		  p7.clicksub();
		  if(pass.equals(confpass))
			{
				 logger.log(LogStatus.PASS, "Sign in completed");
				 String imgg=Screenshot.takeSnapshot(driver);
				  logger.log(LogStatus.PASS,logger.addScreenCapture(imgg)+ "Sign in Successful");
			}
			
			else
			{
				logger.log(LogStatus.FAIL, "Invalid Password");
			}
			 
		  
		
		  
		  
		  		
	      
	    
	

		  
}
	@AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
}
