package org.qa.tests;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;


import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


import org.qa.pages.alertPage;
import org.qa.util.Baseclass;
import org.qa.util.Screenshot;
public class alertclass extends Baseclass
{
	
		ExtentReports report;
		ExtentTest logger; 
		WebDriver driver;
		String exptitle="Alerts";
		alertPage p2;
		Baseclass b=new Baseclass();
		
		@Test
		public void alertDemo()throws IOException, InterruptedException 
		{
			b.launchBrowser();
			driver=new ChromeDriver();
			p2=new alertPage(driver);
			report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo2.html");
			 logger=report.startTest("alertDemo");
			driver.manage().window().maximize();
			 logger.log(LogStatus.INFO, "Browser started ");
			 String baseUrl=b.alertlink();
			 driver.get(baseUrl);
			 logger.log(LogStatus.INFO, "Application is up and running");
			 String title=driver.getTitle();
			 System.out.println(title);
			 Assert.assertTrue(title.contains("Alerts")); 
			  logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+exptitle+"Actual Title:"+" "+title);
			 //First alert box 
			  p2. firstalertl();
			  try
			  {
			   p2.firstalerts();
			  String imgalert=Screenshot.takeSnapshot(driver);
			  logger.log(LogStatus.PASS,logger.addScreenCapture(imgalert)+ "Alert with OK");
			  driver.switchTo().alert().accept();
			  }
			  catch (Exception e) 
			  {
					  if(e.toString().contains("org.openqa.selenium.UnhandledAlertException"))
					   {
						  p2.firstalerts();
						  String imgalert=Screenshot.takeSnapshot(driver);
						  logger.log(LogStatus.PASS,logger.addScreenCapture(imgalert)+ "Alert with OK");
						 
					      Alert alert = driver.switchTo().alert();
					      alert.accept();
					   }
			  }
			  
			  
			  //Second alert box
			  
			  p2.secondalertlinks();
			  try
			  {
				  p2.secondalerts();
				  String imgalert1=Screenshot.takeSnapshot(driver);
				  logger.log(LogStatus.PASS,logger.addScreenCapture(imgalert1)+ "Alert with OK and Cancel");
				  driver.switchTo().alert().accept();
			  }
			  catch (Exception e) 
			  {
					  if(e.toString().contains("org.openqa.selenium.UnhandledAlertException"))
					  { p2.firstalerts();
						  String imgalert1=Screenshot.takeSnapshot(driver);
						  logger.log(LogStatus.PASS,logger.addScreenCapture(imgalert1)+ "Alert with OK and Cancel");
						  Alert alert = driver.switchTo().alert();
					      alert.accept();
					   }
			  }
			 
			 
			  
			  String exp="You pressed Ok";
			  String act=p2.gettingtext();
			  
			  if(exp.contentEquals(act))
				{
					logger.log(LogStatus.PASS, "verified"+" "+"Expected:"+" "+exp+"Actual:"+" "+ act);
				}

				else
				{
					logger.log(LogStatus.FAIL, "verified"+" "+"Expected:"+" "+exp+"Actual:"+" "+act);
				}
			  
			  //Third alert box
			  p2.thirdalertlinks();
			  
			  try
			  {
				  p2.thirdalerts();
				  driver.switchTo().alert().sendKeys("Jasmine");
				  String imgalert2=Screenshot.takeSnapshot(driver);
				  logger.log(LogStatus.PASS,logger.addScreenCapture(imgalert2)+ "Alert with Textbox");
				  driver.switchTo().alert().accept();
			  }
			  catch (Exception e) 
			  {
					  if(e.toString().contains("org.openqa.selenium.UnhandledAlertException"))
					   {
						  p2.firstalerts();
						  driver.switchTo().alert().sendKeys("Jasmine");
						  String imgalert2=Screenshot.takeSnapshot(driver);
						  logger.log(LogStatus.PASS,logger.addScreenCapture(imgalert2)+ "Alert with Textbox");
						  Alert alert = driver.switchTo().alert();
					      alert.accept();
					   }
			  }
			 
			  

			  String exp1="Hello Jasmine How are you today";
			  String act1=p2.gettingtextal();
			  
			  if(exp1.contentEquals(act1))
				{
					logger.log(LogStatus.PASS, "verified"+" "+"Expected:"+" "+exp1+"Actual:"+" "+ act1);
				}

				else
				{
					logger.log(LogStatus.FAIL, "verified"+" "+"Expected:"+" "+exp1+"Actual:"+" "+act1);
				}
			  
		}
		
		 @AfterMethod
		  public void tearDown(ITestResult result)
		  {

		  report.endTest(logger);
		  report.flush();
		   

		  }
		 
}

