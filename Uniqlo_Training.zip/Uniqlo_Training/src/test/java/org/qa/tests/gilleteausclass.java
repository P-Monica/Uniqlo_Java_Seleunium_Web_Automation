package org.qa.tests;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.qa.pages.gilleteaustria;
import org.qa.util.Baseclass;
import org.qa.util.Screenshot;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class gilleteausclass extends Baseclass
{
	ExtentReports report;
	ExtentTest logger; 
	WebDriver driver;
	
	
	gilleteaustria p8;
	Baseclass b=new Baseclass();
	@Test
	public void registerAustria()throws IOException, InterruptedException, FilloException 
	{
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		b.launchBrowser();
		driver=new ChromeDriver();
		 String baseUrl=b.lauchAustria();
		 driver.get(baseUrl);
		p8=new gilleteaustria(driver);
		report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo8.html");
		 logger=report.startTest("registerAustria");
		driver.manage().window().maximize();
		 logger.log(LogStatus.INFO, "Browser started ");
		 
		 String fname="";
			String email="";
			String cemail="";
			String pass="";
			String confpass="";
			String refercode="";
		
		String excelPath="E:\\Java_Workspace\\Automation Project\\Uniqlo_Training\\Form2.xlsx";
		System.out.println(excelPath);
		//Create an Object of Fillo Class
	    
		Fillo fillo = new Fillo();
	    //Create an Object for Connection class and use getConnection()
	    Connection connection = fillo.getConnection(excelPath);
	    //Select all the values present in a sheet
	    String strSelectQuerry = "Select * from Sheet1";
	    System.out.println(strSelectQuerry);
	    
	  //Execute the Select query 
	    	Recordset recordset =null;
	        recordset = connection.executeQuery(strSelectQuerry);
	   //use while loop to iterate through all columns and rows 
	    while(recordset.next())
	    {
	       fname = recordset.getField("FirstName");
	      System.out.println("Firstname  is:"+fname);
	       email=recordset.getField("Email");
	      System.out.println("Email is:"+email);
	      cemail=recordset.getField("ConfEmail");
	      System.out.println("CEmail is:"+cemail);
	     pass=recordset.getField("Password");
	      System.out.println("Password is:"+ pass);
	      confpass=recordset.getField("Confpass");
	      System.out.println("Confpass is:"+confpass);
	      refercode=recordset.getField("referencecode");
	      System.out.println("refercode is:"+refercode);
	      
	      p8.enterfirstname(fname);
	      p8.enteremail(email);
	      p8.enterconfirmemail(cemail);
	      p8.entercpass(pass);
	      p8.enterconfpass(confpass);
	      p8.enterrefcode(refercode);
	      //driver.switchTo().defaultContent();
	      //js.executeScript("window.scrollBy(0,1000)");
	      js.executeScript("window.scrollBy(0,350)");
	      p8.reg();
	      String img1=Screenshot.takeSnapshot(driver);
		  logger.log(LogStatus.PASS,logger.addScreenCapture(img1)+ "Registration is successful");
		  p8.registerbutton();
	    }
	    
		 
	}
	
	@AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
}
