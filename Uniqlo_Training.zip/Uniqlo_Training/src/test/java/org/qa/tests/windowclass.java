package org.qa.tests;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.qa.pages.windows;
import org.qa.util.Baseclass;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class windowclass extends Baseclass
{
	ExtentReports report;
	ExtentTest logger; 
	WebDriver driver;
	String exptitle="Frames & windows";
	windows p3;
	Baseclass b=new Baseclass();
	
	@Test
	public void windowPage()throws IOException, InterruptedException 
	{
		b.launchBrowser();
		driver=new ChromeDriver();
		
		 String baseUrl=b.windowlink();
		 driver.get(baseUrl);
		p3=new windows(driver);
		report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo3.html");
		 logger=report.startTest("windowDemo");
		driver.manage().window().maximize();
		 logger.log(LogStatus.INFO, "Browser started ");
		
		 String mainWindow=driver.getWindowHandle();
		 System.out.println("mainwindow is"+mainWindow);
		 logger.log(LogStatus.INFO, "Application is up and running");
		 String title=driver.getTitle();
		 System.out.println(title);
		 Assert.assertTrue(title.contains("Frames & windows")); 
		  logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+exptitle+"Actual Title:"+" "+title);
		  
		 p3.opennew();
		  p3.firsttab();
		  
		  String pagetitle=" ";
		 
		  Set<String> s1=driver.getWindowHandles();	
			 // Using Iterator to iterate with in windows
			 Iterator<String> itr= s1.iterator();
			 while(itr.hasNext())
			 {
			 String childWindow=itr.next();
			 System.out.println("childwindow"+childWindow);
			    // Compare whether the main windows is not equal to child window. If not equal, we will close.
			 if(!mainWindow.equals(childWindow))
			 {
			 driver.switchTo().window(childWindow);
			 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			 String actualpagetitle=driver.switchTo().window(childWindow).getTitle();
			 pagetitle="Sakinalium | Home";
			 if(actualpagetitle.contentEquals(pagetitle))
				{
					logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+pagetitle+"Actual Title:"+" "+ actualpagetitle);
				}

				else
				{
					logger.log(LogStatus.FAIL, "Title verified"+" "+"Expected Title:"+pagetitle+"Actual Title:"+" "+actualpagetitle);
				}
			 driver.close();
			 }
			 driver.switchTo().window(mainWindow);
			 }
			 
			// driver.close();
			 
			 		 
			 p3.opensecondtab();
			 p3.clicksecondtab();
			 String pagetitle1=" ";
			 
			  Set<String> s2=driver.getWindowHandles();	
				 // Using Iterator to iterate with in windows
				 Iterator<String> itr1= s2.iterator();
				 while(itr1.hasNext())
				 {
				 String childWindow=itr1.next();
				 System.out.println("childwindow"+childWindow);
				    // Compare whether the main windows is not equal to child window. If not equal, we will close.
				 if(!mainWindow.equals(childWindow))
				 {
				 driver.switchTo().window(childWindow);
				 String actualpagetitle=driver.switchTo().window(childWindow).getTitle();
				 pagetitle="Sakinalium | Home";
				 if(actualpagetitle.contentEquals(pagetitle1))
					{
						logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+pagetitle1+"Actual Title:"+" "+ actualpagetitle);
					}

					else
					{
						logger.log(LogStatus.FAIL, "Title verified"+" "+"Expected Title:"+pagetitle1+"Actual Title:"+" "+actualpagetitle);
					}
				 driver.close();
				 }
				 driver.switchTo().window(mainWindow);
				 }
				 
				 p3.clickmultipletab();
				 p3.clickthirdtab();
				 
				 String pagetitle2=" ";
				 
				  Set<String> s3=driver.getWindowHandles();	
					 // Using Iterator to iterate with in windows
					 Iterator<String> itr2= s3.iterator();
					 while(itr2.hasNext())
					 {
					 String childWindow=itr2.next();
					 System.out.println("childwindow"+childWindow);
					    // Compare whether the main windows is not equal to child window. If not equal, we will close.
					 if(!mainWindow.equals(childWindow))
					 {
					 driver.switchTo().window(childWindow);
					 String actualpagetitle=driver.switchTo().window(childWindow).getTitle();
					 pagetitle2="Sakinalium | Home";
					 if(actualpagetitle.contentEquals(pagetitle1))
						{
							logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+pagetitle2+"Actual Title:"+" "+ actualpagetitle);
						}

						else
						{
							logger.log(LogStatus.FAIL, "Title verified"+" "+"Expected Title:"+pagetitle2+"Actual Title:"+" "+actualpagetitle);
						}
					 }
					 }
				 
		 
					 driver.close();
	
	  
}
	@AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
}
