package org.qa.tests;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.qa.pages.datepicker;
import org.qa.util.Baseclass;
import org.qa.util.Screenshot;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class datepickerclass extends Baseclass
{
	ExtentReports report;
	ExtentTest logger; 
	WebDriver driver;
	String exptitle="Datepicker";
	datepicker p5;
	Baseclass b=new Baseclass();
	@Test
	public void dateDemo()throws IOException, InterruptedException 
	{
		b.launchBrowser();
		driver=new ChromeDriver();
		 String baseUrl=b.datepickerlink();
		 driver.get(baseUrl);
		p5=new datepicker(driver);
		report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo5.html");
		 logger=report.startTest("dateDemo");
		driver.manage().window().maximize();
		 logger.log(LogStatus.INFO, "Browser started ");
		 String title=driver.getTitle();
		 System.out.println(title);
		 Assert.assertTrue(title.contains("Datepicker")); 
		  logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+exptitle+"Actual Title:"+" "+title);
		  
		  p5.datepicker_click();
		  p5.date_click();
		  String img1=Screenshot.takeSnapshot(driver);
			 logger.log(LogStatus.PASS,logger.addScreenCapture(img1)+ "Test Passed");

}
	 @AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
}
