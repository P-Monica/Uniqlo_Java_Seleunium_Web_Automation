package org.qa.tests;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.qa.pages.Selectable;
import org.qa.util.Baseclass;
import org.qa.util.Screenshot;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class selectableclass extends Baseclass
{
	ExtentReports report;
	ExtentTest logger; 
	WebDriver driver;
	String exptitle="Selectable";
	Selectable p6;
	Baseclass b=new Baseclass();
	@Test
	public void selectPage()throws IOException, InterruptedException 
	{
		b.launchBrowser();
		driver=new ChromeDriver();
		 String baseUrl=b.selectablelink();
		 driver.get(baseUrl);
		p6=new Selectable(driver);
		report=new ExtentReports("E:\\Java_Workspace\\Report\\Uniqlo6.html");
		 logger=report.startTest("selectPage");
		driver.manage().window().maximize();
		 logger.log(LogStatus.INFO, "Browser started ");
		 String title=driver.getTitle();
		 System.out.println(title);
		 Assert.assertTrue(title.contains("Selectable")); 
		  logger.log(LogStatus.PASS, "Title verified"+" "+"Expected Title:"+exptitle+"Actual Title:"+" "+title);
		 
		
	    	 
	          String first="";
	          
	    	  List<WebElement> Items = driver.findElements(By.xpath("//li[@class='ui-widget-content']"));
	    	  System.out.println("Size of an Item:"+Items.size());
	    	  int size =Items.size();
	    	  
	    	  int size1=size-7;
	    
			    for(int i=0;i<size1;i++)
			    {
			    System.out.println(i);
			    WebElement Item1 = Items.get(i);
			    System.out.println("Item1"+Item1);
			    Item1.click();
			    first=Item1.getText();
			    logger.log(LogStatus.PASS, "The text obtained is:"+first);
			    }
	   
			    
			    String img1=Screenshot.takeSnapshot(driver);
				 logger.log(LogStatus.PASS,logger.addScreenCapture(img1)+ "Test Passed");
				 
				 p6.click_serialize();
				 p6.selectone_click();
				 
				 String img2=Screenshot.takeSnapshot(driver);
				 logger.log(LogStatus.PASS,logger.addScreenCapture(img2)+ "Test Passed");
				 
		  
}
	 @AfterMethod
	  public void tearDown(ITestResult result)
	  {

	  report.endTest(logger);
	  report.flush();
	   

	  }
}
